﻿open System


let choice = Unchecked.defaultof<unit> , Unchecked.defaultof<unit>
let endgame = false
let mutable foodcounter : int = 1

printfn "Create your own virtual pet"

printfn "What color should your pet be?"
let color = System.Console.ReadLine()

printfn "What is their name?"
let name = System.Console.ReadLine()

printfn "Your pet is ready"

printfn $"You see a little {color} fluffy furball before you. It's your pet, {name}. They look at you expectantly."

while (endgame = false) do
    if foodcounter > 5 then Console.BackgroundColor <- ConsoleColor.Red; Console.Beep(800,200) else Console.BackgroundColor <- ConsoleColor.Black; Console.Beep(37,1)
    printfn ""
    
    if foodcounter > 5 then printfn $"You're pet looks a little sad. After a few seconds you hear their tummy rumbling."
    printfn "What would you like to do? (feed/pet/play/walk/teach)"
    Console.BackgroundColor <- ConsoleColor.Black
    let action = 
        match System.Console.ReadLine() with
        
        |"feed" -> if foodcounter > 0 then printfn $"You streth forth your hand with the delicious treat in it. {name} eagerly eats it from your hand. The little fluffball jumps in their happiness.", foodcounter <- foodcounter * 0 
                        else printfn $"As you reach your hand towards {name} they turn they head away, like sayig i don't want it.", foodcounter <- foodcounter
        
        |"pet" -> if foodcounter < 6 then printfn $"You reach your hand towards {name}. The {color} fluffball moves closer to your hand. As you start petting them you can see how happy they are." , foodcounter <- foodcounter+1 
                    else printfn $"{name} looks at you sadly. They stomach rumbles louder." , foodcounter <- foodcounter+1
        
        |"play" -> if foodcounter < 6 then printfn $"You grab a ball and throw it. {name} runs for it and happily brings it back to you. They are very happy and excited." , foodcounter <- foodcounter+2 
                    else printfn $"{name} looks at you sadly. They stomach rumbles louder." , foodcounter <- foodcounter+1
        
        |"walk" -> if foodcounter < 6 then printfn $"You go towards the door. As your furball sees it they start happily jumping toward you. You open the door and take a small walk outside the house. The air is refreshing for you and {name} too." , foodcounter <- foodcounter+2 
                    else printfn $"{name} looks at you sadly. They stomach rumbles louder." , foodcounter <- foodcounter+1
        
        |"teach" -> if foodcounter < 6 then printfn $"You take out {name}'s favourite treats from your pocket. The little {color} furball is excited. You teach them a new trick you saw on the internet. {name} really enjoys the process and the treats." , foodcounter <- foodcounter+1
                    else printfn $"{name} looks at you sadly. They stomach rumbles louder." , foodcounter <- foodcounter+1
        
        |_ -> printfn $"Please choose from the following list: feed, pet, play, walk, teach" , foodcounter <- foodcounter
   
    choice = action